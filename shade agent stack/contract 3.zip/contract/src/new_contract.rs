use near_sdk::borsh::{self, BorshDeserialize, BorshSerialize};
use near_sdk::{env, near_bindgen, AccountId, Balance, Promise};
use std::collections::HashMap;

#[near_bindgen]
#[derive(BorshDeserialize, BorshSerialize)]
pub struct PurchaseIncentive {
    pub rewards: HashMap<AccountId, Balance>,
}

impl Default for PurchaseIncentive {
    fn default() -> Self {
        Self {
            rewards: HashMap::new(),
        }
    }
}

#[near_bindgen]
impl PurchaseIncentive {
    pub fn verify_and_reward(&mut self, user: AccountId, proof: String) -> Promise {
        // Simulated verification process (Replace with actual API call or validation logic)
        if proof.contains("valid") {
            let reward: Balance = 10_000_000_000_000_000_000_000; // 10 NEAR yocto
            self.rewards.insert(user.clone(), reward);
            env::log_str(&format!("User {} has been rewarded {} tokens", user, reward));
            
            // Transfer tokens to the user (ensure contract has sufficient funds)
            Promise::new(user).transfer(reward)
        } else {
            env::log_str("Invalid purchase proof");
            Promise::new(env::current_account_id())
        }
    }
}
